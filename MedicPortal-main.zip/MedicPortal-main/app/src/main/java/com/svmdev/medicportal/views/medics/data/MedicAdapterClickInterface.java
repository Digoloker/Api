package com.svmdev.medicportal.views.medics.data;

public interface MedicAdapterClickInterface {

    void onCallMedic(String name, String number);

    void onChatMedic(String name, String url);

}
