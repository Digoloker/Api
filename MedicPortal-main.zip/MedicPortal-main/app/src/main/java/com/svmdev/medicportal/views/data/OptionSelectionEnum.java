package com.svmdev.medicportal.views.data;

public enum OptionSelectionEnum {
    DIAGNOSTIC,
    CONSULTATION,
    NURSE,
    AMBULANCE,
    LABWORK,
    MEDICINE
}
