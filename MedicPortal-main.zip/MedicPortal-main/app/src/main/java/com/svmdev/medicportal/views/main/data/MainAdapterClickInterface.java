package com.svmdev.medicportal.views.main.data;

import com.svmdev.medicportal.data.model.Home;

public interface MainAdapterClickInterface {

    void onLoadSpecialists(Home selection);

}
