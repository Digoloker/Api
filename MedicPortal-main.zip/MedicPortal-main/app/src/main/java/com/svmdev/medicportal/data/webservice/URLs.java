package com.svmdev.medicportal.data.webservice;

public class URLs {

    public static final String homeSpecialists = "https://raw.githubusercontent.com/PortalTelemedicina/mobile-test/main/api/home_specialists.json";
    public static final String dentalSpecialists = "https://raw.githubusercontent.com/PortalTelemedicina/mobile-test/main/api/list_specialist_dental_care.json";
    public static final String heartSpecialists = "https://raw.githubusercontent.com/PortalTelemedicina/mobile-test/main/api/list_specialist_dermatology.json";
    public static final String dermatologySpecialists = "https://raw.githubusercontent.com/PortalTelemedicina/mobile-test/main/api/list_specialist_dermatology.json";

}
