Aplicativo para Android, utilizando lingaugem Java para Android 5.0 ou superior, com as seguintes caracteristicas


- Arquitetura utilizada: MVVM (Model-View-ViewModelr);
- Uso do Retrofit 2 para as requisições da API;
- Layout com Constraints para responsividade;
- RecycleViews e celulas personalizadas para exibição dos conteudos;
- Uso de banco de dados SQLite para dados em cache.

Projeto já exportado para rodar diretamente no Android Studio
